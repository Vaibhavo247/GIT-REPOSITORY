celsius = prompt("Enter a celsius value: ");
const fahrenheit = (celsius * 1.8) + 32


console.log(`${celsius} degree celsius is equal to ${fahrenheit.toFixed(2)} degree fahrenheit.`);