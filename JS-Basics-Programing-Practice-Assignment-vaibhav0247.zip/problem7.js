function FindN(n){
    
    if (n<0){
        console.log("Error"); 
    }
    else if(n>=0){
        return Math.pow(n, 2);
    };
};
console.log(FindN(18));