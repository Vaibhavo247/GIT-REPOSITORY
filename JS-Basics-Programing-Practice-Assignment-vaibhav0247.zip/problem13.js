let num = 5;
let series = num * (num + 1);
console.log("series: ", series);